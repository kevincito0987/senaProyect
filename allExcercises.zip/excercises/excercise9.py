def excercise9():
    print(
            """
                Dado N, escribir el producto desde 1 hasta N.  
            """
                )
    
    n = int(input("Ingresa el número: "))
    
    for i in range(1, n+1):
        print(i)    